﻿# 文件命名约束

> Wiki 页面文件必须遵守以下命名规则，否则可能导致搜索引擎索引失败或路径解析异常。

## 硬约束

| 约束 | 规则 | 原因 |
|------|------|------|
| 扩展名 | **必须 `.md`** | 搜索引擎只索引 `.md` 文件；其他扩展名被忽略 |
| 路径深度 | 不超过 4 层（从 `data/wiki/` 计） | 推荐: `wiki/source/article.md` (3层) |
| 非法字符 | 禁止 `\` / `:` / `*` / `?` / `"` / `<` / `>` / `|` | Windows/Unix 文件系统限制 |
| 编码 | **UTF-8 without BOM** | 搜索引擎的 frontmatter 解析器不支持 BOM；GBK/Shift-JIS 导致乱码 |
| 路径遍历 | 禁止 `../` 或绝对路径 | writer.rs 中的 `is_safe_path()` 会拒绝 |

## 软约束

| 约束 | 建议 | 原因 |
|------|------|------|
| 文件名长度 | ≤80 字符（不含扩展名） | 过长文件名在终端和搜索引擎中显示不友好 |
| 分隔符 | 用 `-` 分隔单词，禁止空格和 `_` | 空格在 URL 中需转义；`_` 在 Obsidian 链接中显示为粗体 |
| 大小写 | 全小写 | 避免 Windows/macOS/Linux 大小写敏感不一致 |
| 分类前缀 | 按 `source/` / `entity/` / `concept/` / `synthesis/` 归类 | 搜索引擎的 `list(path="source/")` 可精确过滤 |

## 示例

```
✅ wiki/source/rete-algorithm-optimization.md
✅ wiki/entity/chatgpt-transformer.md
✅ wiki/concept/attention-mechanism.md
✅ wiki/synthesis/mcp-vs-openapi-comparison.md

❌ wiki/source/Rete算法优化.md              ← 含中文，路径混乱
❌ wiki/source/Rete Algorithm Optimization.md ← 含空格
❌ wiki/source/rete_algorithm_optimization.md  ← 含下划线
❌ wiki/entity/foo/bar/baz/deep/article.md     ← 超过4层
❌ data/wiki/../raw/article.md                 ← 路径遍历，被拒绝
```
