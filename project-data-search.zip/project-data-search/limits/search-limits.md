# 搜索引擎约束

> 基于自带的 `search-engine/` 搜索机制，使用时有以下局限性。

## 搜索模式

| 模式 | 能力 | 限制 |
|------|------|------|
| `keyword` | 关键词精确匹配，适合术语和名称搜索 | BM25 词频评分；不处理同义词 |
| `semantic` | 基于 bigram 重合的语义近似匹配 | 非真实向量搜索，语义理解有限 |
| `hybrid` (默认) | RRF 融合 keyword + semantic 分数 | 综合两者结果 |

## token 消耗

| 操作 | tokens | 说明 |
|------|--------|------|
| `search()` 返回 5 个 snippets | **~150 tokens** | 恒定，不随知识库大小变化 |
| `read()` 读取一页 | **页面 token 数** | 取决于页面长度，建议单页 ≤4000 tokens |
| `write()` 写入一页 | **内容 token 数 + 索引重建** | 索引重建是后台操作，不消耗推理 context |
| `reindex()` | ~0 (工具调用开销) | 在后台执行，不占用 context window |

## 规模上限

| 指标 | 上限 | 超出后果 |
|------|------|----------|
| Wiki 页面数 | **≤1000 页** | 搜索时间 2000 页时约 200ms；基本可用但变慢 |
| 单页大小 | 推荐 ≤4000 tokens (~10KB markdown) | 超大页面在 read() 时占用大量 context |
| 索引重建 | 1000 页约 3-5 秒 | 期间搜索仍可用（旧索引），新写入的内容暂不可搜 |
| 并发写入 | 不支持并发 write() | 多页面更新应串行执行 |

## 使用前提

- **首次使用**：运行 `python search-engine/index.py` 初始化索引
- **日常维护**：`write()` 自动重建索引，无需手动操作
- **增量重建**：`python search-engine/index.py -i` 快速更新

## 升级路径

超过 1000 页后，可将 `search-engine/` 替换为更专业的搜索引擎（如使用 Tantivy 或 Elasticsearch 构建），只需保持 `search()`/`read()`/`write()`/`reindex()`/`list()` 接口不变即可。
