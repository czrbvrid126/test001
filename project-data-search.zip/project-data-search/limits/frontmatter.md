﻿# Frontmatter 字段约束

> 所有 Wiki 页面的 YAML frontmatter 必须遵守以下约束。

## 必填字段

| 字段 | 类型 | 约束 | 违规后果 |
|------|------|------|----------|
| `title` | string | 非空，≤100 字符 | 搜索引擎拒绝索引，页面不可搜索 |
| `description` | string | 非空，**≤200 字符** | 同上；超过 200 字符搜索引擎截断，snippet 不完整 |
| `type` | string | 必须是 `source` / `entity` / `concept` / `synthesis` 之一 | 无效 type 在索引时被跳过 |
| `created` | string | 格式 `YYYY-MM-DD` | 索引时 frontmatter 解析失败 |
| `updated` | string | 格式 `YYYY-MM-DD` | 同上 |

## 建议字段

| 字段 | 类型 | 建议 | 无此字段的影响 |
|------|------|------|---------------|
| `tags` | string[] | 至少 1 个标签 | search() 的 tag 过滤不可用 |
| `confidence` | float | 0.0~1.0，新页面默认 0.9 | lint 标记"缺 confidence" |
| `sources` | string[] | 来源摘要页必填 | 无法追踪知识来源 |
| `links` | string[] | 推荐填写 | 影响知识图谱完整性 |

## 禁止的字段

- `id` —— 搜索引擎自动分配，勿手动填写
- 任何含个人身份信息（PII）的字段
