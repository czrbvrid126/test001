﻿# project-data-search

> 基于 LLM Wiki 模式的本地知识库技能。自带搜索引擎，复制即用。

## 快速开始

```bash
# 搜索引擎命令
python search-engine/index.py                # 初始化索引
python search-engine/search.py "关键词"      # 搜索
python search-engine/search.py "关键词" keyword  # 关键词模式
python search-engine/search.py "关键词" semantic 5  # 语义模式
python search-engine/serve.py                # MCP 服务

# 工作流脚本
bash scripts/ingest.sh ~/docs/article.md    # 摄入新来源
bash scripts/lint.sh                        # 健康检查
```

## 核心文件

| 文件 | 作用 |
|------|------|
| [SOUL.md](SOUL.md) | 核心哲学 —— 先读这个 |
| [SKILL.md](SKILL.md) | 工作流指令 —— 喂给智能体 |

| [search-engine/](search-engine/README.md) | 自带搜索引擎 |
| [templates/](templates/) | 页面模版 |
| [patterns/](patterns/) | 最佳实践 |
| [limits/](limits/) | 约束规则 |
| [memory/](memory/) | 项目经验 |
| [data/](data/) | 知识库本身 |

## 适配其他智能体

| 目标 | 操作 |
|------|------|
| Claude Code | `cp SKILL.md CLAUDE.md` |
| Cursor | `cp SKILL.md .cursorrules` |
| Windsurf | `cp SKILL.md .windsurfrules` |
| 通用 | 对话首条粘贴 SKILL.md 内容 |

## 依赖

零。纯 Python 搜索引擎（标准库）；纯 markdown 知识库。
