#!/usr/bin/env python3
"""
search.py — 搜索知识库
用法: ./search-engine/search.py <关键词> [mode] [top_k]
  mode:   hybrid (默认), keyword, semantic
  top_k:  结果数量，默认 5

零外部依赖（仅 Python 标准库）
"""
import argparse
import hashlib
import json
import math
import os
import re
import sys
import time
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
WIKI_ROOT = (SCRIPT_DIR / ".." / "data").resolve()
INDEX_DIR = WIKI_ROOT / ".index"
INDEX_FILE = INDEX_DIR / "index.dat"
CACHE_FILE = INDEX_DIR / "query_cache.json"

# 缓存配置
CACHE_TTL = 60          # 缓存有效期（秒）
CACHE_MAX_ENTRIES = 100  # 最大缓存条目数

# 中英文 + 数字分词正则（与 Bash 版一致）
TOKEN_RE = re.compile(r"[a-z0-9\u4e00-\u9fff]+")


def tokenize(text: str) -> list[str]:
    """分词，过滤单字符"""
    lower = text.lower()
    tokens = TOKEN_RE.findall(lower)
    return [t for t in tokens if len(t) > 1]


class QueryCache:
    """文件级查询结果缓存"""

    def __init__(self, cache_path: Path, ttl: int = CACHE_TTL, max_entries: int = CACHE_MAX_ENTRIES):
        self.cache_path = cache_path
        self.ttl = ttl
        self.max_entries = max_entries
        self._data = self._load()

    def _load(self) -> dict:
        if self.cache_path.exists():
            try:
                return json.loads(self.cache_path.read_text("utf-8"))
            except (json.JSONDecodeError, OSError):
                pass
        return {"version": 1, "entries": {}}

    def _save(self):
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        self.cache_path.write_text(json.dumps(self._data, ensure_ascii=False, indent=2), "utf-8")

    def _make_key(self, query: str, mode: str, top_k: int) -> str:
        raw = f"{query.strip().lower()}|{mode}|{top_k}"
        return hashlib.md5(raw.encode()).hexdigest()

    def get(self, query: str, mode: str, top_k: int, index_mtime: float) -> list[dict] | None:
        """获取缓存。过期或索引已变更则返回 None"""
        key = self._make_key(query, mode, top_k)
        entry = self._data.get("entries", {}).get(key)
        if not entry:
            return None

        # 检查 TTL
        if time.time() - entry.get("cached_at", 0) > self.ttl:
            del self._data["entries"][key]
            self._save()
            return None

        # 检查索引是否已变更
        if entry.get("index_mtime", 0) < index_mtime:
            del self._data["entries"][key]
            self._save()
            return None

        return entry.get("results")

    def set(self, query: str, mode: str, top_k: int, results: list[dict], index_mtime: float):
        """写入缓存"""
        key = self._make_key(query, mode, top_k)
        entries = self._data.setdefault("entries", {})

        # 超过上限时淘汰最旧的条目
        if key not in entries and len(entries) >= self.max_entries:
            oldest = min(entries.keys(), key=lambda k: entries[k].get("cached_at", 0))
            del entries[oldest]

        entries[key] = {
            "query": query,
            "mode": mode,
            "top_k": top_k,
            "results": results,
            "cached_at": time.time(),
            "index_mtime": index_mtime,
        }
        self._save()

    def clear(self):
        """清空所有缓存"""
        self._data = {"version": 1, "entries": {}}
        self._save()


def parse_index(index_path: Path) -> list[dict]:
    """解析 index.dat，返回记录列表"""
    records = []
    content = index_path.read_text("utf-8", errors="replace")
    # 空行分隔记录
    for block in content.strip().split("\n\n"):
        if not block.strip():
            continue
        rec = {}
        for line in block.splitlines():
            if ":" in line:
                key, _, val = line.partition(":")
                rec[key.strip()] = val.strip()
        if rec.get("path"):
            records.append(rec)
    return records


def keyword_score(record: dict, terms: list[str]) -> float:
    """BM25 风格关键词评分"""
    score = 0.0
    path = record.get("path", "")
    title = record.get("title", "")
    desc = record.get("desc", "")
    tags = record.get("tags", "")

    for term in terms:
        # Title matches (+3.0)
        if term in title.lower():
            score += 3.0
        # Description matches (+1.5)
        if term in desc.lower():
            score += 1.5
        # Tag matches (+2.0)
        if term in tags.lower():
            score += 2.0
        # Path matches (+1.0)
        if term in path.lower():
            score += 1.0

        # TF: count occurrences in all text
        all_text = f"{title} {desc} {tags} {path}".lower()
        count = all_text.count(term)
        score += 0.5 * count

    return score


def semantic_score(record: dict, terms: list[str]) -> float:
    """Bigram 重叠评分（伪语义）"""
    score = 0.0
    text = f"{record.get('desc', '')} {record.get('tags', '')}".lower()

    for term in terms:
        # 对每个查询词提取所有 length-2 子串
        for i in range(len(term) - 1):
            bigram = term[i:i+2]
            if bigram in text:
                score += 0.3

    return score


def search(query: str, mode: str = "hybrid", top_k: int = 5,
           use_cache: bool = True) -> list[dict]:
    """执行搜索，返回排序后的结果列表"""
    if not INDEX_FILE.exists():
        print("Index not found. Run: search-engine/index.py", file=sys.stderr)
        sys.exit(1)

    terms = tokenize(query)
    if not terms:
        print("No valid search terms (all too short).")
        return []

    # 缓存检查
    index_mtime = INDEX_FILE.stat().st_mtime
    cache = QueryCache(CACHE_FILE) if use_cache else None
    cache_hit = False

    if cache:
        cached = cache.get(query, mode, top_k, index_mtime)
        if cached is not None:
            cache_hit = True
            print("[cache HIT]", file=sys.stderr)
            return cached
    else:
        print("[cache SKIP]", file=sys.stderr)

    # 实时计算
    records = parse_index(INDEX_FILE)

    results = []
    for rec in records:
        kw = keyword_score(rec, terms)
        sem = semantic_score(rec, terms)

        if mode == "keyword":
            final = kw
        elif mode == "semantic":
            final = sem
        else:  # hybrid
            final = kw + 0.5 * sem

        if final > 0:
            results.append({
                "path": rec.get("path", ""),
                "title": rec.get("title", ""),
                "desc": rec.get("desc", ""),
                "conf": rec.get("conf", ""),
                "score": final,
            })

    # 按分数降序排列
    results = results[:top_k]
    results.sort(key=lambda r: r["score"], reverse=True)

    # 写入缓存
    if cache and not cache_hit:
        cache.set(query, mode, top_k, results, index_mtime)
        print("[cache MISS → written]", file=sys.stderr)

    return results


def format_results(query: str, mode: str, results: list[dict]) -> str:
    """格式化为与 Bash 版一致的输出"""
    lines = []
    lines.append(f"Search: {query}  (mode: {mode})")
    lines.append("======================")
    lines.append("")

    for i, r in enumerate(results, 1):
        conf_info = f" [conf: {r['conf']}]" if r["conf"] else ""
        lines.append(f"[{i}] {r['path']}  (score: {r['score']:.2f}){conf_info}")
        if r["desc"]:
            lines.append(f"    {r['desc']}")
        lines.append("")

    lines.append("======================")
    lines.append(f"{len(results)} results found.")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="搜索知识库")
    parser.add_argument("query", nargs="?", default="", help="搜索关键词")
    parser.add_argument("mode", nargs="?", default="hybrid",
                        choices=["hybrid", "keyword", "semantic"],
                        help="搜索模式（默认 hybrid）")
    parser.add_argument("top_k", nargs="?", type=int, default=5,
                        help="返回结果数量（默认 5）")
    parser.add_argument("--no-cache", action="store_true",
                        help="跳过缓存，强制重新计算")
    parser.add_argument("--clear-cache", action="store_true",
                        help="清空查询缓存")
    args = parser.parse_args()

    # 纯缓存管理操作
    if args.clear_cache:
        QueryCache(CACHE_FILE).clear()
        print("Query cache cleared.", file=sys.stderr)
        if not args.query:
            return

    if not args.query:
        print("Usage: ./search-engine/search.py <query> [mode] [top_k]")
        print("       ./search-engine/search.py --clear-cache")
        print("  mode:  hybrid (default), keyword, semantic")
        print("  top_k: result count (default 5)")
        sys.exit(1)

    results = search(args.query, args.mode, args.top_k,
                     use_cache=not args.no_cache)
    output = format_results(args.query, args.mode, results)
    print(output)


if __name__ == "__main__":
    main()
