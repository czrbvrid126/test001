#!/usr/bin/env python3
"""
serve.py — MCP 兼容搜索服务 (stdio JSON-RPC)
用法: ./search-engine/serve.py

通过 stdin/stdout 监听 search/read/write/reindex/list 命令

零外部依赖（仅 Python 标准库）
"""
import json
import os
import subprocess
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
WIKI_ROOT = (SCRIPT_DIR / ".." / "data").resolve()
INDEX_DIR = WIKI_ROOT / ".index"
INDEX_FILE = INDEX_DIR / "index.dat"

# 确保索引存在
if not INDEX_FILE.exists():
    subprocess.run([sys.executable, str(SCRIPT_DIR / "index.py")],
                   capture_output=True)

print("wiki search server running (stdio transport)", file=sys.stderr)
print(f"  wiki-root: {WIKI_ROOT}", file=sys.stderr)


def json_response(req_id, result):
    """发送 JSON-RPC 成功响应"""
    resp = {"jsonrpc": "2.0", "id": req_id, "result": result}
    sys.stdout.write(json.dumps(resp, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def json_error(req_id, message):
    """发送 JSON-RPC 错误响应"""
    resp = {
        "jsonrpc": "2.0",
        "id": req_id,
        "error": {"message": message, "code": -32000},
    }
    sys.stdout.write(json.dumps(resp, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def do_search(query: str, mode: str = "hybrid", top_k: int = 5) -> str:
    """调用 search.py 并返回纯文本结果"""
    result = subprocess.run(
        [sys.executable, str(SCRIPT_DIR / "search.py"), query, mode, str(top_k)],
        capture_output=True, text=True,
    )
    return result.stdout.strip()


def do_read(path: str) -> str:
    """读取页面内容"""
    abs_path = WIKI_ROOT / path
    # 安全检查：防止路径穿越
    try:
        abs_path = abs_path.resolve()
        abs_path.relative_to(WIKI_ROOT.resolve())
    except ValueError:
        return f"error: path traversal detected: {path}"

    if not abs_path.exists() or not abs_path.is_file():
        return f"error: file not found: {path}"

    content = abs_path.read_text("utf-8", errors="replace")
    return content


def do_write(path: str, content: str) -> dict:
    """写入/更新页面，自动重建索引"""
    abs_path = WIKI_ROOT / path
    # 安全检查
    try:
        abs_path = abs_path.resolve()
        abs_path.relative_to(WIKI_ROOT.resolve())
    except ValueError:
        return {"error": f"path traversal detected: {path}"}

    created = not abs_path.exists()
    abs_path.parent.mkdir(parents=True, exist_ok=True)
    abs_path.write_text(content, "utf-8")

    # 增量重建索引
    subprocess.run(
        [sys.executable, str(SCRIPT_DIR / "index.py"), "-i"],
        capture_output=True,
    )

    return {"created": created, "reindexed": True}


def do_list(filter_path: str = "", filter_tag: str = "") -> list[dict]:
    """列出页面，支持 path/tag 过滤"""
    results = []
    if not INDEX_FILE.exists():
        return results

    content = INDEX_FILE.read_text("utf-8", errors="replace")
    for block in content.strip().split("\n\n"):
        if not block.strip():
            continue
        rec = {}
        for line in block.splitlines():
            if ":" in line:
                key, _, val = line.partition(":")
                rec[key.strip()] = val.strip()

        path = rec.get("path", "")
        if filter_path and not path.startswith(filter_path):
            continue

        tags = rec.get("tags", "")
        if filter_tag:
            tag_list = [t.strip() for t in tags.split(",") if t.strip()]
            if filter_tag not in tag_list:
                continue

        results.append({
            "path": path,
            "title": rec.get("title", ""),
            "description": rec.get("desc", ""),
            "tags": tags,
        })

    return results


def parse_json_rpc(line: str) -> tuple | None:
    """解析 JSON-RPC 请求行，返回 (method, req_id, params) 或 None"""
    try:
        req = json.loads(line)
    except json.JSONDecodeError:
        return None

    method = req.get("method", "")
    req_id = req.get("id")
    params = req.get("params", {})
    if not isinstance(params, dict):
        params = {}
    return method, req_id, params


def main():
    # 逐行读取 stdin（JSON-RPC 通常一行一个请求）
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue

        parsed = parse_json_rpc(line)
        if parsed is None:
            # 非 JSON 行直接忽略（兼容初始化消息等）
            continue

        method, req_id, params = parsed
        if req_id is None:
            # Notification（无 id），不响应
            continue

        try:
            if method == "search":
                query = params.get("query", "")
                mode = params.get("mode", "hybrid")
                top_k = int(params.get("top_k", 5))
                result = do_search(query, mode, top_k)
                json_response(req_id, result)

            elif method == "read":
                path = params.get("path", "")
                result = do_read(path)
                json_response(req_id, result)

            elif method == "write":
                path = params.get("path", "")
                content = params.get("content", "")
                result = do_write(path, content)
                json_response(req_id, result)

            elif method == "reindex":
                subprocess.run(
                    [sys.executable, str(SCRIPT_DIR / "index.py"), "-i"],
                    capture_output=True,
                )
                json_response(req_id, {"reindexed": True})

            elif method == "list":
                filter_path = params.get("path", "")
                filter_tag = params.get("tag", "")
                result = do_list(filter_path, filter_tag)
                json_response(req_id, result)

            else:
                # 未知方法，静默忽略（兼容 JSON-RPC 初始化等）
                pass

        except Exception as e:
            json_error(req_id, str(e))


if __name__ == "__main__":
    main()
