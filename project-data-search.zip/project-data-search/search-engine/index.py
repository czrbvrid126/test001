#!/usr/bin/env python3
"""
index.py — 构建搜索引擎索引
用法: ./search-engine/index.py [-i]
  -i  增量模式（只处理变化的文件）

零外部依赖（仅 Python 标准库）
"""
import argparse
import hashlib
import os
import re
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
WIKI_ROOT = (SCRIPT_DIR / ".." / "data").resolve()
INDEX_DIR = WIKI_ROOT / ".index"
INDEX_FILE = INDEX_DIR / "index.dat"
CHECKSUM_FILE = INDEX_DIR / "checksum.txt"


def parse_frontmatter(content: str):
    """解析 YAML frontmatter，返回 (frontmatter_dict, body_text)"""
    fm = {
        "title": "",
        "description": "",
        "type": "",
        "tags": "",
        "confidence": "",
        "created": "",
        "updated": "",
    }
    # 必须 --- 开头
    if not content.startswith("---"):
        return fm

    parts = content.split("---", 2)
    if len(parts) < 3:
        return fm

    fm_block = parts[1].strip()
    for line in fm_block.splitlines():
        line = line.strip()
        if ":" not in line:
            continue
        key, _, val = line.partition(":")
        key = key.strip().lower()
        val = val.strip().strip('"').strip("'")
        if key in fm:
            # tags 特殊处理: 去除方括号
            if key == "tags":
                val = val.strip("[]").replace('"', "").replace("'", "")
            fm[key] = val

    return fm


def sha256_of_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def index_md_files(incremental: bool):
    """遍历所有 .md 文件构建索引"""
    INDEX_DIR.mkdir(parents=True, exist_ok=True)

    # 加载旧 checksums（增量模式）
    old_checksums: dict[str, str] = {}
    if incremental and CHECKSUM_FILE.exists():
        for line in CHECKSUM_FILE.read_text("utf-8").splitlines():
            parts = line.strip().split(" ", 1)
            if len(parts) == 2:
                old_checksums[parts[1]] = parts[0]

    new_checksums: dict[str, str] = {}
    added = updated = skipped = 0
    seen_paths: set[str] = set()
    records: list[str] = []

    md_files = sorted(WIKI_ROOT.rglob("*.md"))
    for file_path in md_files:
        # 跳过索引目录本身
        if INDEX_DIR in file_path.parents:
            continue

        rel_path = str(file_path.relative_to(WIKI_ROOT)).replace("\\", "/")
        seen_paths.add(rel_path)

        file_hash = sha256_of_file(file_path)
        new_checksums[rel_path] = file_hash

        content = file_path.read_text("utf-8", errors="replace")
        fm = parse_frontmatter(content)
        title = fm["title"] or file_path.stem

        # 构建记录
        record = (
            f"path:{rel_path}\n"
            f"title:{title}\n"
            f"desc:{fm['description']}\n"
            f"type:{fm['type']}\n"
            f"tags:{fm['tags']}\n"
            f"conf:{fm['confidence']}\n"
            f"created:{fm['created']}\n"
            f"updated:{fm['updated']}\n"
            "\n"  # 空行分隔
        )
        records.append(record)

        # 统计：增量模式下哈希相同记 skipped，否则按新旧记 added/updated
        if incremental and rel_path in old_checksums and old_checksums[rel_path] == file_hash:
            skipped += 1
        elif rel_path in old_checksums:
            updated += 1
        else:
            added += 1

    # 检测删除的文件
    removed = 0
    for old_path in old_checksums:
        if old_path not in seen_paths:
            removed += 1

    # 写入索引
    INDEX_FILE.write_text("".join(records), "utf-8")

    # 写入 checksums（此处修复了 Bash 版的子 shell 赋值丢失 bug）
    checksum_lines = [f"{h} {p}\n" for p, h in sorted(new_checksums.items())]
    CHECKSUM_FILE.write_text("".join(checksum_lines), "utf-8")

    total = added + updated + skipped
    print(f"Indexed {total} files ({added} added, {updated} updated, {skipped} skipped, {removed} removed)")


def main():
    parser = argparse.ArgumentParser(description="构建搜索引擎索引")
    parser.add_argument("-i", "--incremental", action="store_true", help="增量模式（只处理变化的文件）")
    args = parser.parse_args()
    index_md_files(incremental=args.incremental)


if __name__ == "__main__":
    main()
