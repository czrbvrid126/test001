﻿# Bundled Search Engine

> 技能自带的搜索引擎。纯 Python 实现，零外部依赖（仅标准库）。
> 兼容标准搜索接口，适合小到中型知识库（≤1000 页）。

## 初始化索引

```bash
# 首次使用或全量重建
python index.py

# 增量更新（只处理变化文件，推荐日常使用）
python index.py -i
```

## 搜索

```bash
# 关键词搜索（默认 hybrid 混合模式）
python search.py "光合作用 温度"

# 指定模式
python search.py "光合作用" keyword
python search.py "光合作用" semantic

# 自定义返回数量
python search.py "光合作用" hybrid 10
```

## MCP 兼容服务（LLM 集成）

```bash
# 启动 stdio 服务器
python serve.py
```

支持的命令：`search`, `read`, `write`, `reindex`, `list`

## 索引缓存
