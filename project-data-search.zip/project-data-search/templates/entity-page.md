---
title: "实体名称"
description: "≤200 字精炼摘要 — 搜索引擎显示的 snippet"
type: entity
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: []
sources: []
links: []
confidence: 0.9
---

# 实体名称

## 概述

对该实体的完整描述。涵盖其定义、背景、重要性。

## 关键属性 / 特征

- **属性一**: 值 / 描述
- **属性二**: 值 / 描述

## 相关来源

- [[source/来源文件]] — 提供了哪些信息
- [[source/来源文件]] — 提供了哪些信息

## 关联实体和概念

- [[entity/关联实体]] — 关系描述
- [[concept/关联概念]] — 关系描述

## 时间线（如适用）

| 时间 | 事件 |
|------|------|
| YYYY-MM | 事件描述 |

## 待解决的问题 / 开放问题

- 问题一
- 问题二
