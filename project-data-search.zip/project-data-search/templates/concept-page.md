---
title: "概念名称"
description: "≤200 字精炼摘要 — 搜索引擎显示的 snippet"
type: concept
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: []
sources: []
links: []
confidence: 0.9
---

# 概念名称

## 定义

清晰、准确的定义。描述该概念的核心内涵。

## 关键方面

### 方面一

详细说明。

### 方面二

详细说明。

## 与其他概念的关系

- [[concept/关联概念]] — 关系描述（包含、被包含、对立、互补）
- [[entity/相关实体]] — 该概念在哪些实体上体现

## 相关来源

- [[source/来源文件]] — 该来源如何讨论此概念

## 笔记

额外观察、矛盾观点、个人理解。

## 参见

- [[concept/参见概念]]
