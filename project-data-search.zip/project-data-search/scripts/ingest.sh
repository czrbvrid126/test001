#!/usr/bin/env bash
# ============================================================
# ingest.sh — 摄入一个新的来源文档到知识库
# 用法: ./scripts/ingest.sh <来源文件路径> [来源标题]
#
# 将文件复制到 data/raw/，然后由 LLM 处理后续的
# 摘要写入、搜索引擎自动索引和日志记录。
# ============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RAW_DIR="${SCRIPT_DIR}/data/raw"
WIKI_DIR="${SCRIPT_DIR}/data/wiki"
LOG_DIR="${SCRIPT_DIR}/data/log"

SOURCE_FILE="$1"
TITLE="${2:-$(basename "$SOURCE_FILE" .md)}"

if [ -z "$SOURCE_FILE" ]; then
    echo "❌ 用法: $0 <来源文件路径> [来源标题]"
    exit 1
fi

if [ ! -f "$SOURCE_FILE" ]; then
    echo "❌ 文件不存在: $SOURCE_FILE"
    exit 1
fi

# 复制到 raw/ 目录
BASENAME="$(basename "$SOURCE_FILE")"
DEST="${RAW_DIR}/${BASENAME}"

# 如果目标已存在，添加时间戳避免覆盖
if [ -f "$DEST" ]; then
    TIMESTAMP=$(date +%Y%m%d_%H%M%S)
    DEST="${RAW_DIR}/${TIMESTAMP}_${BASENAME}"
fi

cp "$SOURCE_FILE" "$DEST"
echo "✅ 已复制到: $DEST"
echo "📝 来源标题: $TITLE"
echo ""
echo "接下来请 LLM 执行摄入工作流："
echo "  1. 读取 $DEST，理解核心内容"
echo "  2. 与人类讨论关键要点"
echo "  3. 创建 wiki/source/${BASENAME%.md}.md → 写好 description 字段"
echo "  4. 更新或创建相关的实体/概念页 → 同步更新它们的 description"
echo "  5. write() 写入所有页面 → 搜索引擎自动重建索引"
echo "  6. 记录到 ${LOG_DIR}/$(date +%Y-%m-%d).md"
