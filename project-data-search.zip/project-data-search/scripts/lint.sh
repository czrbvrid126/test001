﻿#!/usr/bin/env bash
# ============================================================
# lint.sh — 知识库健康检查
# 用法: ./scripts/lint.sh
#
# 检查项目：
#   1. 基础统计
#   2. description 字段完整性
#   3. confidence 健康检查
#   4. 孤立页面检查
#   5. 搜索引擎索引检查
#   6. 最后活动
# ============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
RAW_DIR="${SCRIPT_DIR}/data/raw"
WIKI_DIR="${SCRIPT_DIR}/data/wiki"
INDEX_FILE="${SCRIPT_DIR}/data/index.md"
LOG_DIR="${SCRIPT_DIR}/data/log"

echo "知识库健康检查"
echo "======================"
echo ""

# 1. 基础统计
echo "基础统计"
RAW_COUNT=$(find "$RAW_DIR" -type f 2>/dev/null | wc -l)
WIKI_COUNT=$(find "$WIKI_DIR" -type f -name "*.md" 2>/dev/null | wc -l)
LOG_COUNT=$(find "$LOG_DIR" -type f -name "*.md" 2>/dev/null | wc -l)
echo "  原始来源: ${RAW_COUNT} 个文件"
echo "  Wiki 页面: ${WIKI_COUNT} 个文件"
echo "  日志天数:  ${LOG_COUNT} 天"
echo ""

# 2. description 字段完整性检查
echo "description 字段检查"
MISSING_DESC=0
LONG_DESC=0
CONF_MISSING=0
ALL_PAGES=$(find "$WIKI_DIR" -type f -name "*.md" 2>/dev/null)
for page in $ALL_PAGES; do
    rel="${page#$SCRIPT_DIR/}"
    DESC=$(grep -m1 '^description:' "$page" 2>/dev/null || echo "")
    if [ -z "$DESC" ]; then
        echo " 缺少 description: $rel"
        MISSING_DESC=$((MISSING_DESC + 1))
    fi
    DESC_TEXT=$(echo "$DESC" | sed 's/^description: "//;s/"$//' 2>/dev/null || echo "")
    if [ ${#DESC_TEXT} -gt 210 ] 2>/dev/null; then
        echo " description 可能超长 (>200): $rel"
        LONG_DESC=$((LONG_DESC + 1))
    fi
    CONF=$(grep -m1 '^confidence:' "$page" 2>/dev/null || echo "")
    if [ -z "$CONF" ]; then
        echo " 缺少 confidence: $rel"
        CONF_MISSING=$((CONF_MISSING + 1))
    fi
done
if [ "$MISSING_DESC" -eq 0 ] && [ "$LONG_DESC" -eq 0 ] && [ "$CONF_MISSING" -eq 0 ]; then
    echo "  所有页面 description + confidence 完整"
fi
echo ""

# 3. confidence 健康检查
echo "confidence 分布"
LOW_CONF=0
MED_CONF=0
HIGH_CONF=0
for page in $ALL_PAGES; do
    CONF_VAL=$(grep -m1 '^confidence:' "$page" 2>/dev/null | sed 's/^confidence: //' || echo "")
    if [ -n "$CONF_VAL" ]; then
        if (( $(echo "$CONF_VAL < 0.5" | bc -l 2>/dev/null) )); then
            LOW_CONF=$((LOW_CONF + 1))
        elif (( $(echo "$CONF_VAL < 0.8" | bc -l 2>/dev/null) )); then
            MED_CONF=$((MED_CONF + 1))
        else
            HIGH_CONF=$((HIGH_CONF + 1))
        fi
    fi
done
echo "  high (>=0.8): ${HIGH_CONF}"
echo "  med (0.5~0.8): ${MED_CONF}"
echo "  low (<0.5): ${LOW_CONF}"
echo ""

# 4. 孤立页面检查
echo "孤立页面检查（无入链的 Wiki 页面）"
ORPHANS=()
for page in $ALL_PAGES; do
    PAGENAME=$(basename "$page" .md)
    if [ -f "$INDEX_FILE" ]; then
        if ! grep -qi "$PAGENAME" "$INDEX_FILE" 2>/dev/null; then
            ORPHANS+=("$page")
        fi
    fi
done
if [ ${#ORPHANS[@]} -eq 0 ]; then
    echo "  没有发现孤立页面"
else
    for o in "${ORPHANS[@]}"; do
        rel="${o#$SCRIPT_DIR/}"
        echo "  $rel (未在 index.md 中列出)"
    done
fi
echo ""

# 5. 搜索引擎索引检查
echo "搜索引擎索引检查"
if [ -d "${SCRIPT_DIR}/data/.index" ]; then
    echo "  .index/ 搜索引擎缓存目录存在"
    META_COUNT=$(grep -c "^path:" "${SCRIPT_DIR}/data/.index/index.dat" 2>/dev/null || echo "0")
    echo "  索引条目: $META_COUNT"
else
    echo "  未检测到 .index/ 目录。需先运行: python search-engine/index.py"
fi
echo ""

# 6. 最后活动
echo "最近操作"
if [ -d "$LOG_DIR" ]; then
    LATEST_LOG=$(ls -t "$LOG_DIR"/*.md 2>/dev/null | head -3 || true)
    if [ -n "$LATEST_LOG" ]; then
        echo "$LATEST_LOG" | while read -r f; do
            rel="${f#$SCRIPT_DIR/}"
            LAST_ENTRY=$(grep "^## \[" "$f" 2>/dev/null | tail -1 || echo "(无条目)")
            echo "  $rel -> $LAST_ENTRY"
        done
    else
        echo "  (无日志)"
    fi
fi

echo ""
echo "======================"
echo "检查完成。请 LLM 根据结果进行修复和优化。"
