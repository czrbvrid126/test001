﻿# project-data-search — 本地知识库技能

基于 [LLM Wiki](references/llm-wiki.md) 模式的本地知识库维护技能。自带搜索引擎（`search-engine/`），零安装依赖，随技能文件夹直接复制使用。

## 核心思想

传统 RAG 在每次提问时都从零发现知识；本技能反其道而行——**增量构建并维护一个持久的 Wiki**。

- **原始来源不变** → `data/raw/` 的文件是只读的、不可变的
- **Wiki 由 LLM 维护** → `data/wiki/` 下的所有页面由 LLM 创建、更新、交叉引用
- **知识持续积累** → 每摄入一个来源、每回答一个问题，Wiki 都变得更丰富

## 三层架构

```
┌─────────────────────────────────┐
│   data/raw/  原始来源 (只读)      │
├─────────────────────────────────┤
│   data/wiki/  Wiki 页面 (LLM写)   │
├─────────────────────────────────┤
│   SKILL.md   模式定义 + 工作流    │
└─────────────────────────────────┘
┌─────────────────────────────────┐
│   search-engine/  自带搜索引擎    │
└─────────────────────────────────┘
```

## description 字段 —— 搜索引擎的 snippet

每个 Wiki 页面必须在 frontmatter 中有 `description` 字段，作为搜索引擎的摘要 snippet：

```yaml
---
title: "页面标题"
description: "≤200 字精炼摘要 — 搜索引擎显示的 snippet，LLM 写页面时就要写好"
confidence: 0.9
---
```

- `description` 是搜索结果的摘要行——像 Google snippet 一样
- LLM 创建或更新页面时就必须写好，≤200 字符
- **写 `description` 就是写索引条目**——不需要单独的索引更新步骤

## confidence 字段 —— 知识可靠性追踪

每个页面标记 `confidence` 分值 (0.0~1.0)：

| 分值 | 含义 |
|------|------|
| 0.9~1.0 | 高可靠，多个来源交叉验证 |
| 0.7~0.9 | 中等可靠，单一来源但有依据 |
| 0.5~0.7 | 推测性，需进一步验证 |
| <0.5 | 待确认，标记了矛盾或不确定 |

## 导航机制

所有规模统一使用 `search-engine/` 中的自带搜索引擎：

### 命令行搜索
```bash
# 初始化索引（首次使用或全量重建）
python search-engine/index.py

# 搜索
python search-engine/search.py "光合作用 温度"
# 输出: [1] wiki/entity/photosynthesis.md (score: 5.2) [conf: 0.94]
#       植物利用叶绿素将光能转化为化学能的过程
```

### MCP 服务（供 LLM 智能体调用）
```bash
python search-engine/serve.py
# 启动后通过 stdin/stdout JSON-RPC 协议监听
```

MCP 工具对应表：

| 工具 | 功能 |
|------|------|
| `search()` | 关键词/语义混合搜索，返回 snippets |
| `read()` | 读取完整页面或特定章节 |
| `write()` | 创建或更新页面，**自动重建索引** |
| `reindex()` | 重建索引（增量，只处理变化文件） |
| `list()` | 按路径或标签列出页面 |

关键设计：**`write()` 自动触发 reindex**，LLM 不需要记得"写完要重建索引"。

## 目录结构说明

```
project-data-search/
├── README.md            ← 入口简介
├── SOUL.md              ← 核心哲学
├── SKILL.md             ← 工作流指令（喂给智能体）
├── search-engine/       ← 自带搜索引擎（零安装，复制即用）
│   ├── index.py         ← 构建索引
│   ├── search.py        ← 命令行搜索
│   ├── serve.py         ← MCP 服务（供 LLM 调用）
│   └── README.md
├── scripts/             ← 辅助工具（grep/lint）
├── references/          ← 参考资料（llm-wiki.md）
├── templates/           ← 页面模版（含 description 字段）
├── limits/              ← 约束规则
├── memory/              ← 项目经验和决策记录
├── patterns/            ← 可复用的最佳实践方法
└── data/
    ├── raw/             ← 原始来源文档（只读、不可变）
    ├── wiki/            ← LLM 生成的 Wiki 页面
    │   ├── source/      ← 来源摘要
    │   ├── entity/      ← 实体页
    │   ├── concept/     ← 概念页
    │   └── synthesis/   ← 综合分析
    ├── index.md         ← 人类浏览用目录（LLM 不依赖此文件）
    ├── log/             ← 按日期存放的操作日志 YYYY-MM-DD.md
    └── .index/          ← 搜索引擎自动生成的索引缓存（运行 index.py 后创建，不手动修改）
```

## data/.index/ —— 搜索引擎索引缓存

这个目录由 `search-engine/index.py` 自动生成，**请不要手动编辑**。

| 文件 | 作用 |
|------|------|
| `index.dat` | 所有 Wiki 页面的元数据（path, title, desc, tags, conf 等） |
| `checksum.txt` | 文件 SHA256 校验和，用于增量更新时判断哪些文件变了 |

`write()` 写入页面时自动触发 reindex，所以日常使用中**你不需要手动运行 index.py**。
只有在以下情况需要手动运行：
- 首次配置技能后
- 手动在文件系统中添加/删除/修改了 .md 文件（非通过 write()）
- 切换 git 分支后（索引是生成缓存，不提交到版本控制）

### 1. 摄入 (Ingest)

放入新来源到 `data/raw/` 后：

1. 读取来源文档，理解核心内容
2. 与人类讨论关键要点
3. 创建来源摘要页 → **写好 `description` 字段** (≤200 字)
4. 更新相关的实体页和概念页 → **同时更新它们的 `description`**
5. 使用 `write()` 写入所有页面，**索引自动重建**
6. 在 `data/log/` 中添加日志条目

### 2. 查询 (Query)

当我提问时：

1. `search("问题", mode="hybrid", top_k=5)` 获取 snippets
2. 根据 snippets 决定哪些页面需要 `read()` 完整内容
3. 综合答案并标注引用
4. 有价值的答案 → 用 `templates/synthesis-page.md` + `write()` 归档
5. 在 `data/log/` 中记录查询

### 3. 检查 (Lint)

定期健康检查：

1. 页面间矛盾 → 更新 `confidence`
2. `description` 字段质量（精炼度、≤200 字符）
3. `confidence` 过低的页面是否需要更新
4. 发现频繁被提及但缺少独立页面的概念
5. 运行 `reindex(incremental=true)` 确保搜索索引最新

## 页面约定

### 文件名规范
- 来源摘要：`wiki/source/<来源简称>.md`
- 实体页：`wiki/entity/<实体名称>.md`
- 概念页：`wiki/concept/<概念名称>.md`
- 综合/分析页：`wiki/synthesis/<主题>.md`

### 页面格式
每个 Wiki 页面包含 YAML frontmatter：
```yaml
---
title: 页面标题
description: ≤200 字精炼摘要 —— 搜索引擎 snippet
type: source | entity | concept | synthesis
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: [标签1, 标签2]
confidence: 0.9
sources: [来源1, 来源2]
links: [相关页面路径]
---
```

### 日志格式
`data/log/YYYY-MM-DD.md` 中每条记录以固定前缀开头：
```markdown
## [YYYY-MM-DD] ingest | 来源标题
## [YYYY-MM-DD] query | 用户提问摘要
## [YYYY-MM-DD] lint | 检查结果摘要
```

## 原则

1. **原始来源不可变** —— `data/raw/` 中的文件从不修改
2. **Wiki 持续积累** —— 有价值的答案要归档回 Wiki
3. **矛盾要标记** —— 降低旧页面的 `confidence` 并注明原因
4. **description 是索引** —— 写页面时写好 description，不需要单独的索引步骤
5. **日志要记录** —— 每次操作都记录到 `data/log/`



