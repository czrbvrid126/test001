﻿# Frontmatter 规则

> 每个 Wiki 页面的 frontmatter 必须遵循以下规则。

## 必填字段

| 字段 | 说明 | 约束 |
|------|------|------|
| `title` | 页面标题 | 非空 |
| `description` | 搜索引擎显示的 snippet | ≤200 字符，独立可读 |
| `type` | 页面类型 | `source` / `entity` / `concept` / `synthesis` |
| `created` | 创建日期 | `YYYY-MM-DD` |
| `updated` | 最后更新日期 | `YYYY-MM-DD` |
| `tags` | 标签 | 至少一个标签 |

## 建议字段

| 字段 | 说明 | 默认值 |
|------|------|--------|
| `confidence` | 可靠性评分 (0.0~1.0) | 新页面默认 0.9 |
| `sources` | 相关来源文件列表 | 来源页面必填 |
| `links` | 双向链接列表 | 建议填写 |

## description 编写原则

- **像 Google snippet 一样写**：独立可读，不依赖外部上下文
- **包含区别性特征**：让读者一眼知道这页是否相关
- **避免 filler 词**：不要用"本文介绍了"、"这是一个"、"该页面描述了"
- **≤200 字符**：超长会被搜索引擎截断

## 经验记录

<!-- 在此记录实际使用中发现的 frontmatter 最佳实践 -->
